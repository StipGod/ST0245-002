# Plantillas para los talleres

En este repositorio se incluye la plantilla de cada uno de los talleres. 
Recuerde que puede modificar los parametros que reciben los diferentes metodos, crear nuevos
metodos y demas, pero la idea es que logre dimensionar de manera facil y clara de los archivos y 
metodos que debe crear.

Tambien puede agregar otros metodos que considere necesarios, pero las pruebas las haremos utilizando
los nombres de las plantillas. 

Las plantillas tambien tienen un metodo `main` en la clase `Main` que al ser ejecutado da una breve
muestra del funcionamiento de los metodos (por tanto deben implementar todos los metodos correctamente
antes de que este `main` funcione a pleno).
